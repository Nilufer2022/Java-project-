package Lab1_Oct_21_Nilufer;

public class InitializingArraysWithInputValues {
    public static void main(String[] args) {
       // Initializing arrays with input values
        int[] myArray = new int[]{3, 5, 7};  // Integer array initializing
        String[] myStringArray = new String[]{"pink", "yellow", "blue"}; //String array initializing

    }
}