package Lab1_Problems;

import java.util.Scanner;
import java.util.*;

public class Bonus {


            public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
                List<Double> numbers = new ArrayList<>();
                List<String> operations = new ArrayList<>();

                // Getting the first number from the user
                System.out.print("Enter number: ");
                numbers.add(scanner.nextDouble());

                while (true) {
                    System.out.print("Enter operation symbol +, -, *, / or = to calculate: ");
                    String operation = scanner.next();

                    if (operation.equals("=")) {
                        break;  // Exit the loop and calculate the result when entered =
                    }

                    operations.add(operation);  // Store the operation for consequently calculation

                    System.out.print("Enter number: ");
                    numbers.add(scanner.nextDouble());  // Add the next number to calculate
                }

                // Calculate the result using BEDMAS rule
                double result = calculate(numbers, operations);
                System.out.println("Result: " + result); //result will be printed.

            }

    private static double calculate(List<Double> numbers, List<String> operations) {
        // Calculate multiplication and division first
        for (int i = 0; i < operations.size(); i++) {
            if (operations.get(i).equals("*") || operations.get(i).equals("/")) {
                double num1 = numbers.get(i);
                double num2 = numbers.get(i + 1);
                double intermediateResult = operations.get(i).equals("*") ? num1 * num2 : num1 / num2;

                // Replace numbers and operations for next calculations
                numbers.set(i, intermediateResult);
                numbers.remove(i + 1);
                operations.remove(i);
                i--; // Adjust index after removal
            }
        }

        // Calculate addition and subtraction later
        double result = numbers.get(0);
        for (int i = 0; i < operations.size(); i++) {
            if (operations.get(i).equals("+")) {
                result += numbers.get(i + 1);
            } else if (operations.get(i).equals("-")) {
                result -= numbers.get(i + 1);
            }
        }

        return result; // return result
            }
    }


